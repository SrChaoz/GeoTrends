import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import HeatmapPage from './pages/HeatmapPage';

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 p-4">
        <Routes>
          <Route path="/" element={<HeatmapPage />} />
        </Routes>
      </main>
    </div>
  );
}
