const Legend = ({ maxValue }) => {
  const legendItems = [
    { color: '#d73027', label: 'Alto' },        // Rojo intenso
    { color: '#f46d43', label: 'Medio-Alto' },  // Naranja-rojo  
    { color: '#fdae61', label: 'Medio' },       // Amarillo-naranja
    { color: '#fee08b', label: 'Medio-Bajo' },  // Amarillo claro
    { color: '#e6f598', label: 'Bajo' },        // Verde claro
    { color: '#abdda4', label: 'Muy Bajo' },    // Verde
    { color: '#66c2a5', label: 'Mínimo' },      // Verde-azul
    { color: '#d1d5db', label: 'Sin Datos' }    // Gris
  ];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
        Leyenda
      </h3>
      <div className="space-y-2">
        {legendItems.map((item, index) => (
          <div key={index} className="flex items-center space-x-2">
            <div 
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: item.color }}
            ></div>
            <span className="text-xs text-gray-700 dark:text-gray-300">
              {item.label}
            </span>
          </div>
        ))}
      </div>
      {maxValue && (
        <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-600">
          <p className="text-xs text-gray-600 dark:text-gray-400">
            Valor máximo: <span className="font-semibold text-gray-900 dark:text-white">{maxValue}</span>
          </p>
        </div>
      )}
    </div>
  );
};

export default Legend;
