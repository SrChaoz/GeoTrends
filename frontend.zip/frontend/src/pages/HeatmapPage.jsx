import { useState } from 'react';
import SearchBar from '../components/SearchBar';
import HeatmapMarkers from '../components/HeatmapMarkers';
import Legend from '../components/Legend';
import Navbar from '../components/Navbar';
import { MapContainer, TileLayer } from 'react-leaflet';

export default function HeatmapPage() {
  const [keyword, setKeyword] = useState('');
  const [heatData, setHeatData] = useState({});

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-100 transition-colors duration-300">
      <Navbar />
      
      <main className="max-w-full mx-auto px-6 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Panel lateral */}
          <div className="lg:col-span-1 space-y-6">
            <SearchBar
              keyword={keyword}
              setKeyword={setKeyword}
              setHeatData={setHeatData}
            />
            
            {/* Leyenda */}
            <Legend maxValue={Object.keys(heatData).length > 0 ? Math.max(...Object.values(heatData)) : null} />
          </div>
          
          {/* Mapa */}
          <div className="lg:col-span-3">
            <div className="bg-white dark:bg-gray-50 rounded-lg shadow-sm overflow-hidden">
              <div className="p-4 border-b border-gray-200 dark:border-gray-300">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-800">
                  Mapa Interactivo
                </h2>
              </div>
              <div className="h-[600px] w-full bg-gray-100">
                <MapContainer
                  center={[-1.8312, -78.1834]} // centro de Ecuador
                  zoom={6}
                  className="h-full w-full"
                  style={{ backgroundColor: '#f3f4f6' }} // Fondo gris claro
                >
                  <TileLayer
                    attribution="&copy; OpenStreetMap contributors"
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    opacity={0.4} // Más transparencia para que se parezca al diseño
                  />
                  <HeatmapMarkers heatData={heatData} />
                </MapContainer>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
